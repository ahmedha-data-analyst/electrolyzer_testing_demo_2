"""HydroStar NextGen Electrolyser Testing and Validation — local Demo mode.

This dashboard simulates the 16 process instruments shown on NX-PID-001 so the
layout, alarm colours, alarm thresholds, trend charts, sensor table and event
behaviour can be reviewed before the physical sensors and the final live-data
architecture exist. It runs entirely offline:

    streamlit run app_v2.py

No Supabase, Raspberry Pi, secrets, credentials or network access is used or
required. Every displayed value is generated locally and labelled SIMULATED.

Design notes for the next developer
-----------------------------------
* Internal sensor keys (for example ``FT003_O2`` and ``FT003_N2``) are used as
  dataframe keys instead of the displayed P&ID tags because NX-PID-001 shows
  ``FT-003`` on both the oxygen product stream and the nitrogen feed. Keying on
  the displayed tag would silently overwrite one instrument with the other.
* The two gas analysers are labelled on the P&ID without unique numeric
  instrument tags, so their displayed tag is honestly shown as ``Tag pending``
  rather than an invented tag.
* Instruments whose four limits are all null are shown grey as
  ``No approved limits`` (UNCONFIGURED), never green NORMAL: a green state
  would wrongly imply the value had been checked against approved limits.
* Demo history is stable across Streamlit reruns because every sample is a
  pure function of (scenario seed, sensor key, sample index). Widget-driven
  reruns therefore recompute identical values; only genuinely new five-second
  samples are appended (see ``advance_sim``).
* The alarm-event log cannot duplicate events on refresh because samples are
  processed exactly once (a ``last_k`` pointer) and an event is recorded only
  when a sensor's state differs from its previously recorded state
  (see ``collect_events``).

All alarm limits in this file and in the registry are provisional dashboard
values for layout and behaviour testing. They are not PLC, SIS or approved
plant trip settings, and this dashboard issues no control commands.
"""

from __future__ import annotations

import base64
import html
import math
import re
import zlib
from dataclasses import dataclass
from datetime import timezone
from pathlib import Path
from string import Template
from typing import Callable, Iterable, Mapping, Optional, Sequence

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yaml

try:
    from zoneinfo import ZoneInfo

    DISPLAY_TZ = ZoneInfo("Europe/London")
    DISPLAY_TZ_NAME = "Europe/London"
except Exception:  # pragma: no cover - zoneinfo ships with Python 3.11+
    DISPLAY_TZ = timezone.utc
    DISPLAY_TZ_NAME = "UTC"


# ---------------------------------------------------------------------------
# 1. Constants
# ---------------------------------------------------------------------------

APP_DIR = Path(__file__).resolve().parent
LOGO_FILE = APP_DIR / "logo.png"
REGISTRY_FILE = APP_DIR / "provisional_sensor_registry_v2.yaml"

PAGE_TITLE = "NextGen Electrolyser Testing and Validation"
PAGE_SUBTITLE = "5 kW Electrolyser Testing"

SAMPLE_SECONDS = 5
REFRESH_INTERVAL = "5s"
HISTORY_SECONDS = 6 * 3600
HISTORY_MINUTES = HISTORY_SECONDS / 60.0
HISTORY_SAMPLES = HISTORY_SECONDS // SAMPLE_SECONDS  # 4,320 samples
EVENT_LIMIT = 100
MAX_CHART_POINTS = 1_200

ACTIVE_MAX_AGE_SECONDS = 20.0
DELAYED_MAX_AGE_SECONDS = 60.0

# HydroStar brand palette (Section 16 of the build brief).
PRIMARY = "#A7D730"
SECONDARY = "#499823"
DARK_GREY = "#30343C"
LIGHT_GREY = "#8C919A"
WATER_BLUE = "#4EA8DE"
AMBER = "#F6A609"
RED = "#D32F2F"

FONT_STACK = "'Hind', 'Inter', Arial, sans-serif"

SOURCE_SIMULATED = "SIMULATED"
QUALITY_GOOD = "GOOD"
QUALITY_STALE = "STALE"
QUALITY_MISSING = "MISSING"
QUALITY_BAD = "BAD"
BAD_QUALITY = frozenset({QUALITY_STALE, QUALITY_MISSING, QUALITY_BAD})

STATE_NORMAL = "NORMAL"
STATE_UNKNOWN = "UNKNOWN"
STATE_UNCONFIGURED = "UNCONFIGURED"

# Deterministic worst-first tie ordering for safety summaries (Section 8).
ALARM_PRECEDENCE: tuple[str, ...] = (
    "HH", "LL", "H", "L", STATE_NORMAL, STATE_UNCONFIGURED, STATE_UNKNOWN,
)
_PRECEDENCE_RANK = {state: rank for rank, state in enumerate(ALARM_PRECEDENCE)}

CRITICAL_STATES = frozenset({"HH", "LL"})
WARNING_STATES = frozenset({"H", "L"})

STATE_COLOURS = {
    STATE_NORMAL: SECONDARY,
    "L": AMBER,
    "H": AMBER,
    "LL": RED,
    "HH": RED,
    STATE_UNKNOWN: LIGHT_GREY,
    STATE_UNCONFIGURED: LIGHT_GREY,
}
SEVERITY_WORD = {
    "HH": "Critical",
    "LL": "Critical",
    "H": "Warning",
    "L": "Warning",
    STATE_NORMAL: "Normal",
    STATE_UNCONFIGURED: "No approved limits",
    STATE_UNKNOWN: "Unknown",
}

TAG_PENDING = "Tag pending"
NO_APPROVED_LIMITS = "No approved limits"
NOT_CALCULATED = "Not calculated"

MEASUREMENT_DECIMALS = {
    "level_deviation": 1,
    "temperature": 1,
    "pressure": 2,
    "flow": 2,
    "gas_concentration": 2,
    "conductivity": 0,
}
MEASUREMENT_LINE_COLOURS = {
    "level_deviation": SECONDARY,
    "temperature": PRIMARY,
    "pressure": WATER_BLUE,
    "flow": WATER_BLUE,
    "gas_concentration": SECONDARY,
    "conductivity": WATER_BLUE,
}

# Internal keys in registry order. Displayed P&ID tags are NOT used as keys
# because FT-003 appears twice on NX-PID-001 (oxygen product outlet and
# nitrogen feed) and would overwrite itself in any tag-keyed structure.
EXPECTED_KEYS: tuple[str, ...] = (
    "LT001", "TT001", "PT001", "LT002",
    "CT001",
    "FT001_H2", "FT002_O2",
    "ANALYSER_H2_IN_O2", "ANALYSER_O2_IN_H2",
    "TT002_O2", "PT002_O2", "FT003_O2", "TT003_H2", "PT003_H2", "FT004_H2",
    "FT003_N2",
)
CRITICAL_CARD_ORDER: tuple[str, ...] = (
    "LT001", "TT001", "PT001", "LT002",
    "FT001_H2", "FT002_O2", "ANALYSER_H2_IN_O2", "ANALYSER_O2_IN_H2",
)

WINDOW_OPTIONS: dict[str, float] = {
    "5 minutes": 5.0,
    "15 minutes": 15.0,
    "1 hour": 60.0,
    "6 hours": 360.0,
}
DEFAULT_WINDOW = "15 minutes"
DEFAULT_TREND_SENSORS = ["LT001", "ANALYSER_H2_IN_O2"]

DEFAULT_CAMPAIGN = "Demo Campaign — Layout and Alarm Validation"
DEFAULT_ELECTROLYTE = "Specification pending"

SAFETY_ITEMS: tuple[tuple[str, tuple[str, ...], str], ...] = (
    ("Gas crossover", ("ANALYSER_H2_IN_O2", "ANALYSER_O2_IN_H2"),
     "Product gas purity against crossover limits."),
    ("Pressure envelope", ("PT001", "PT002_O2", "PT003_H2"),
     "Process pressures against provisional upper limits."),
    ("Temperature envelope", ("TT001", "TT002_O2", "TT003_H2"),
     "Process temperatures against provisional upper limits."),
    ("Level envelope", ("LT001", "LT002"),
     "Halopod level deviation from baseline."),
)

CHART_CONFIG = {
    "displayModeBar": False,
    "displaylogo": False,
    "responsive": True,
    "scrollZoom": False,
}


def stretch_kwargs() -> dict[str, object]:
    """Return the full-width keyword supported by this Streamlit version."""
    try:
        major, minor = (int(part) for part in st.__version__.split(".")[:2])
    except (AttributeError, ValueError):
        return {"use_container_width": True}
    if (major, minor) >= (1, 49):
        return {"width": "stretch"}
    return {"use_container_width": True}


STRETCH = stretch_kwargs()


# ---------------------------------------------------------------------------
# 2. Sensor registry (single source of sensor metadata)
# ---------------------------------------------------------------------------


class RegistryError(RuntimeError):
    """Raised when the sensor registry is missing, unreadable or invalid."""


@dataclass(frozen=True)
class SensorSpec:
    """One process instrument from provisional_sensor_registry_v2.yaml."""

    key: str
    pid_tag: str
    display_name: str
    group_id: int
    group_name: str
    measurement: str
    unit: str
    unit_provisional: bool
    critical: bool
    limits: Mapping[str, Optional[float]]
    source_mode: str
    notes: str = ""

    @property
    def display_tag(self) -> str:
        # The P&ID labels both analysers without a unique numeric instrument
        # tag, so the honest display value is "Tag pending", not an invention.
        return TAG_PENDING if self.pid_tag == "UNASSIGNED" else self.pid_tag

    @property
    def decimals(self) -> int:
        return MEASUREMENT_DECIMALS.get(self.measurement, 2)

    @property
    def configured(self) -> bool:
        return any(value is not None for value in self.limits.values())


REQUIRED_SENSOR_FIELDS = (
    "internal_key", "pid_tag", "display_name", "group_id", "group_name",
    "measurement", "unit", "critical", "limits", "source_mode",
)
LIMIT_KEYS = ("LL", "L", "H", "HH")


def load_registry(path: Path) -> list[SensorSpec]:
    """Load and validate the sensor registry, failing with readable messages."""
    if not path.exists():
        raise RegistryError(
            f"The sensor registry file is missing: {path.name}. "
            "Place provisional_sensor_registry_v2.yaml in the same folder as "
            "app_v2.py and reload the page."
        )
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise RegistryError(
            f"The sensor registry could not be parsed as YAML: {exc}"
        ) from exc

    sensors_raw = raw.get("sensors") if isinstance(raw, dict) else None
    if not isinstance(sensors_raw, list):
        raise RegistryError(
            "The sensor registry does not contain a 'sensors' list."
        )

    problems: list[str] = []
    specs: list[SensorSpec] = []
    seen_keys: set[str] = set()

    for index, entry in enumerate(sensors_raw, start=1):
        if not isinstance(entry, dict):
            problems.append(f"Sensor entry {index} is not a mapping.")
            continue
        missing = [field for field in REQUIRED_SENSOR_FIELDS if field not in entry]
        if missing:
            label = entry.get("internal_key", f"entry {index}")
            problems.append(
                f"Sensor '{label}' is missing required field(s): "
                + ", ".join(missing)
            )
            continue

        key = str(entry["internal_key"])
        if key in seen_keys:
            problems.append(f"Internal key '{key}' is duplicated in the registry.")
            continue
        seen_keys.add(key)

        limits_raw = entry.get("limits")
        limits: dict[str, Optional[float]] = {}
        if not isinstance(limits_raw, dict):
            problems.append(f"Sensor '{key}' has an invalid 'limits' mapping.")
            continue
        limit_error = False
        for limit_name in LIMIT_KEYS:
            value = limits_raw.get(limit_name)
            if value is None:
                limits[limit_name] = None
            else:
                try:
                    limits[limit_name] = float(value)
                except (TypeError, ValueError):
                    problems.append(
                        f"Sensor '{key}' limit {limit_name} is not numeric."
                    )
                    limit_error = True
        if limit_error:
            continue

        specs.append(
            SensorSpec(
                key=key,
                pid_tag=str(entry["pid_tag"]),
                display_name=str(entry["display_name"]),
                group_id=int(entry["group_id"]),
                group_name=str(entry["group_name"]),
                measurement=str(entry["measurement"]),
                unit=str(entry["unit"]),
                unit_provisional=str(entry.get("unit_status", "")) == "provisional",
                critical=bool(entry["critical"]),
                limits=limits,
                source_mode=str(entry["source_mode"]),
                notes=str(entry.get("notes") or ""),
            )
        )

    if len(sensors_raw) != 16:
        problems.append(
            f"The registry must contain exactly 16 sensors, found {len(sensors_raw)}."
        )
    missing_keys = [key for key in EXPECTED_KEYS if key not in seen_keys]
    unexpected_keys = sorted(seen_keys - set(EXPECTED_KEYS))
    if missing_keys:
        problems.append("Missing expected internal key(s): " + ", ".join(missing_keys))
    if unexpected_keys:
        problems.append("Unexpected internal key(s): " + ", ".join(unexpected_keys))

    if problems:
        raise RegistryError(
            "The sensor registry failed validation:\n- " + "\n- ".join(problems)
        )

    # Stable presentation order: group_id first, then registry order.
    specs.sort(key=lambda spec: spec.group_id)
    return specs


# ---------------------------------------------------------------------------
# 3. Alarm engine (the only place threshold comparisons live)
# ---------------------------------------------------------------------------


def classify_alarm(
    value: Optional[float],
    limits: Mapping[str, Optional[float]],
    quality: str,
) -> str:
    """Classify one reading into an alarm state.

    Rules (in order):
      1. MISSING / STALE / BAD quality  -> UNKNOWN (quality takes priority).
      2. Missing or non-numeric value   -> UNKNOWN.
      3. All four limits null           -> UNCONFIGURED (shown grey as
         "No approved limits", never green NORMAL).
      4. value <= LL -> LL;  value <= L -> L;
         value >= HH -> HH;  value >= H -> H;  otherwise NORMAL.
         Exact boundary values therefore count as alarm states.

    No hysteresis is applied because no approved hysteresis values exist yet.
    When they do, add optional ``hysteresis`` / ``previous_state`` parameters
    here rather than scattering comparisons through the UI.
    """
    if quality in BAD_QUALITY:
        return STATE_UNKNOWN
    if value is None:
        return STATE_UNKNOWN
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return STATE_UNKNOWN
    if math.isnan(numeric):
        return STATE_UNKNOWN

    low_low = limits.get("LL")
    low = limits.get("L")
    high = limits.get("H")
    high_high = limits.get("HH")
    if low_low is None and low is None and high is None and high_high is None:
        return STATE_UNCONFIGURED

    if low_low is not None and numeric <= low_low:
        return "LL"
    if low is not None and numeric <= low:
        return "L"
    if high_high is not None and numeric >= high_high:
        return "HH"
    if high is not None and numeric >= high:
        return "H"
    return STATE_NORMAL


def worst_state(states: Iterable[str]) -> str:
    """Most severe state using the deterministic HH, LL, H, L, ... ordering."""
    ranked = [state for state in states if state in _PRECEDENCE_RANK]
    if not ranked:
        return STATE_UNKNOWN
    return min(ranked, key=_PRECEDENCE_RANK.__getitem__)


def state_badge_colours(state: str) -> tuple[str, str]:
    """Background and text colour for an alarm badge (text always shown too)."""
    background = STATE_COLOURS.get(state, LIGHT_GREY)
    foreground = DARK_GREY if background == AMBER else "#ffffff"
    return background, foreground


def alarm_display_text(state: str) -> str:
    """Human wording for an alarm state (UNCONFIGURED reads as its meaning)."""
    return NO_APPROVED_LIMITS if state == STATE_UNCONFIGURED else state


def level_deviation_from_distance(
    raw_distance_cm: float, baseline_distance_mm: float
) -> float:
    """Future Hybrid-mode conversion for the ultrasonic level sensors.

    ``level_deviation_mm = baseline_distance_mm - (raw_distance_cm * 10)``

    A smaller measured distance means a higher liquid level, so positive
    deviation = level has risen. Demo mode deliberately does NOT call this:
    demo level values are generated directly as deviation in millimetres, and
    no approved baseline distance exists yet for LT-001 or LT-002.
    """
    return baseline_distance_mm - (raw_distance_cm * 10.0)


# ---------------------------------------------------------------------------
# 4. Deterministic simulation engine
# ---------------------------------------------------------------------------
# Every sample is a pure function of (scenario seed, sensor key, sample
# index k), built from:
#   * piecewise-linear scenario waypoints (smooth trends and excursions),
#   * two slow sensor-specific sinusoids (gentle wobble),
#   * tiny per-sample jitter from a counter-based hash (splitmix64).
# Because nothing depends on wall-clock randomness, Streamlit reruns caused
# by widgets recompute identical history, and appending sample k tomorrow
# gives the same value as appending it today.

_SM_GAMMA = np.uint64(0x9E3779B97F4A7C15)
_SM_M1 = np.uint64(0xBF58476D1CE4E5B9)
_SM_M2 = np.uint64(0x94D049BB133111EB)
_SALT_PRIME = np.uint64(0xD1B54A32D192ED03)


def _mix64(values: np.ndarray) -> np.ndarray:
    """Vectorised splitmix64 finaliser over uint64 values."""
    with np.errstate(over="ignore"):
        mixed = values + _SM_GAMMA
        mixed = (mixed ^ (mixed >> np.uint64(30))) * _SM_M1
        mixed = (mixed ^ (mixed >> np.uint64(27))) * _SM_M2
        return mixed ^ (mixed >> np.uint64(31))


def _stream_seed(scenario_seed: int, key: str) -> np.uint64:
    """Stable 64-bit stream seed for one (scenario, sensor) pair."""
    with np.errstate(over="ignore"):
        combined = (
            np.uint64(scenario_seed) * np.uint64(0x100000001B3)
        ) ^ np.uint64(zlib.crc32(key.encode("utf-8")))
    return _mix64(np.asarray([combined], dtype=np.uint64))[0]


def _uniform(seed: np.uint64, ks: np.ndarray, salt: int) -> np.ndarray:
    """Deterministic uniforms in [0, 1) for the given sample indices."""
    with np.errstate(over="ignore"):
        counters = ks.astype(np.uint64) * _SM_GAMMA
        counters = counters ^ seed ^ (np.uint64(salt) * _SALT_PRIME)
    hashed = _mix64(counters)
    return (hashed >> np.uint64(11)).astype(np.float64) / float(1 << 53)


def _gaussian(seed: np.uint64, ks: np.ndarray, salt: int) -> np.ndarray:
    """Deterministic standard-normal jitter (Box-Muller, clipped)."""
    u1 = np.clip(_uniform(seed, ks, salt), 1e-12, 1.0)
    u2 = _uniform(seed, ks, salt ^ 0x5851F42D)
    normal = np.sqrt(-2.0 * np.log(u1)) * np.cos(2.0 * np.pi * u2)
    return np.clip(normal, -3.5, 3.5)


def _wobble(seed: np.uint64, t_min: np.ndarray, amplitude: float) -> np.ndarray:
    """Two slow sensor-specific sinusoids: smooth, deterministic variation."""
    if amplitude <= 0:
        return np.zeros_like(t_min)
    params = _uniform(seed, np.arange(4, dtype=np.int64), 0x0BADCAFE)
    period_1 = 18.0 + 24.0 * params[0]   # 18-42 minutes
    period_2 = 6.0 + 7.0 * params[1]     # 6-13 minutes
    phase_1 = 2.0 * np.pi * params[2]
    phase_2 = 2.0 * np.pi * params[3]
    return amplitude * (
        0.7 * np.sin(2.0 * np.pi * t_min / period_1 + phase_1)
        + 0.3 * np.sin(2.0 * np.pi * t_min / period_2 + phase_2)
    )


@dataclass(frozen=True)
class QualityRule:
    """Marks a sensor's samples MISSING or STALE inside a time window.

    ``start_min`` / ``end_min`` are minutes relative to the moment the demo
    session was generated (negative = in the pre-generated history,
    ``end_min=None`` = open-ended into live time).
    """

    sensor: str
    kind: str
    start_min: float
    end_min: Optional[float] = None


@dataclass(frozen=True)
class Scenario:
    """One demo scenario: seed, waypoint profiles and data-quality rules."""

    name: str
    seed: int
    summary: str
    waypoints: Mapping[str, tuple[tuple[float, float], ...]]
    quality_rules: tuple[QualityRule, ...] = ()


# Quiet baselines used whenever a scenario does not override a sensor.
BASELINES: dict[str, float] = {
    "LT001": 0.4,
    "LT002": -0.6,
    "TT001": 44.5,
    "PT001": 1.80,
    "CT001": 500.0,
    "FT002_O2": 0.82,
    "ANALYSER_H2_IN_O2": 0.90,
    "ANALYSER_O2_IN_H2": 1.15,
    "TT002_O2": 43.0,
    "PT002_O2": 1.95,
    "TT003_H2": 45.0,
    "PT003_H2": 1.90,
    "FT003_N2": 4.0,
}

# Hydrogen-side and outlet flows are derived from the oxygen product flow so
# the streams stay physically related: FT-001 tracks roughly twice FT-002 with
# a small dynamic lag plus its own noise (never mathematically identical).
_DERIVED_FLOWS: dict[str, tuple[str, float, float]] = {
    # key: (source key, multiplier, lag seconds)
    "FT001_H2": ("FT002_O2", 2.00, 20.0),
    "FT004_H2": ("FT002_O2", 1.93, 45.0),
    "FT003_O2": ("FT002_O2", 0.95, 30.0),
}

# (wobble amplitude, per-sample jitter sigma) in engineering units.
_WOBBLE_NOISE_BY_MEASUREMENT: dict[str, tuple[float, float]] = {
    "level_deviation": (0.55, 0.04),
    "temperature": (0.85, 0.06),
    "pressure": (0.05, 0.006),
    "gas_concentration": (0.07, 0.010),
    "flow": (0.035, 0.006),
    "conductivity": (7.0, 0.8),
}
_WOBBLE_NOISE_OVERRIDES: dict[str, tuple[float, float]] = {
    "FT001_H2": (0.06, 0.010),   # twice the O2 magnitude, so slightly larger
    "FT004_H2": (0.05, 0.009),
    "FT003_N2": (0.22, 0.03),    # SLPM scale differs from Nm3/h flows
}

# Demo-only electrical channels (not part of the 16 P&ID process sensors).
_ELECTRICAL_BASE: dict[str, tuple[float, float, float]] = {
    # pseudo key: (baseline, wobble amplitude, jitter sigma)
    "STACK_VOLTAGE": (65.6, 0.45, 0.05),
    "STACK_CURRENT": (74.5, 1.10, 0.15),
}


def _scenario(name: str, seed: int, summary: str,
              waypoints: Mapping[str, tuple[tuple[float, float], ...]],
              quality_rules: tuple[QualityRule, ...] = ()) -> Scenario:
    return Scenario(name=name, seed=seed, summary=summary,
                    waypoints=dict(waypoints), quality_rules=quality_rules)


SCENARIOS: dict[str, Scenario] = {
    scenario.name: scenario
    for scenario in (
        _scenario(
            "Normal operation", 101,
            "All configured sensors stay below their provisional limits.",
            {},
        ),
        _scenario(
            "Mixed alarm demonstration", 202,
            "Green, amber, red and grey states are visible together.",
            {
                "LT001": ((-360.0, 0.4), (-235.0, 0.4), (-208.0, 7.0)),
                "LT002": ((-360.0, -0.6), (-218.0, -0.6), (-188.0, -11.3)),
                "TT001": ((-360.0, 46.0),),
                "PT001": ((-360.0, 1.80), (-168.0, 1.80), (-142.0, 2.82)),
                "FT002_O2": ((-360.0, 0.82), (-150.0, 0.82), (-120.0, 0.90)),
                "ANALYSER_H2_IN_O2": ((-360.0, 0.90), (-112.0, 0.90), (-72.0, 3.26)),
                "ANALYSER_O2_IN_H2": ((-360.0, 1.20),),
                "TT002_O2": ((-360.0, 43.0), (-152.0, 43.0), (-116.0, 61.8)),
                "PT002_O2": ((-360.0, 2.00),),
                "TT003_H2": ((-360.0, 45.0), (-102.0, 45.0), (-80.0, 54.0)),
                "PT003_H2": ((-360.0, 1.90), (-132.0, 1.90), (-96.0, 4.26)),
            },
        ),
        _scenario(
            "Level excursion", 303,
            "LT-001 ramps NORMAL, H, HH, then recovers through H to NORMAL.",
            {
                "LT001": (
                    (-360.0, 0.4), (-95.0, 0.4), (-72.0, 7.2), (-52.0, 11.6),
                    (-34.0, 11.6), (-14.0, 7.2), (8.0, 0.4),
                ),
            },
        ),
        _scenario(
            "Temperature excursion", 404,
            "TT-001 ramps NORMAL, H, HH and later moves towards recovery.",
            {
                "TT001": (
                    (-360.0, 44.5), (-80.0, 44.5), (-58.0, 53.5),
                    (-32.0, 61.6), (-6.0, 61.6), (32.0, 46.5),
                ),
            },
        ),
        _scenario(
            "Pressure excursion", 505,
            "PT-001 ramps NORMAL, H, HH and later moves towards recovery.",
            {
                "PT001": (
                    (-360.0, 1.80), (-75.0, 1.80), (-52.0, 2.90),
                    (-26.0, 4.30), (-2.0, 4.30), (36.0, 1.90),
                ),
            },
        ),
        _scenario(
            "Gas crossover event", 606,
            "H2-in-O2 rises through H to HH while O2-in-H2 stays normal.",
            {
                "ANALYSER_H2_IN_O2": (
                    (-360.0, 0.90), (-85.0, 0.90), (-58.0, 2.35),
                    (-30.0, 3.42), (-8.0, 3.42), (22.0, 2.35), (50.0, 1.20),
                ),
            },
        ),
        _scenario(
            "Data-quality fault", 707,
            "FT-001 loses data (gaps) and TT-002 goes stale; alarms turn grey.",
            {},
            quality_rules=(
                QualityRule("FT001_H2", QUALITY_MISSING, -120.0, -100.0),
                QualityRule("FT001_H2", QUALITY_MISSING, -15.0, None),
                QualityRule("TT002_O2", QUALITY_STALE, -20.0, None),
                QualityRule("LT001", QUALITY_MISSING, -190.0, -178.0),
            ),
        ),
    )
}
SCENARIO_ORDER: tuple[str, ...] = tuple(SCENARIOS)
DEFAULT_SCENARIO = "Mixed alarm demonstration"


def _t_minutes(ks: np.ndarray) -> np.ndarray:
    """Sample indices -> minutes relative to the generation moment."""
    return ks.astype(np.float64) * SAMPLE_SECONDS / 60.0 - HISTORY_MINUTES


def _profile(scenario: Scenario, key: str, t_min: np.ndarray) -> np.ndarray:
    """Piecewise-linear waypoint profile (clamped and held at both ends)."""
    waypoints = scenario.waypoints.get(key)
    if not waypoints:
        return np.full(t_min.shape, BASELINES[key], dtype=np.float64)
    xs = np.array([point[0] for point in waypoints], dtype=np.float64)
    ys = np.array([point[1] for point in waypoints], dtype=np.float64)
    return np.interp(t_min, xs, ys)


def _wobble_noise_amplitudes(spec: SensorSpec) -> tuple[float, float]:
    if spec.key in _WOBBLE_NOISE_OVERRIDES:
        return _WOBBLE_NOISE_OVERRIDES[spec.key]
    return _WOBBLE_NOISE_BY_MEASUREMENT.get(spec.measurement, (0.05, 0.01))


def _raw_values(scenario: Scenario, spec: SensorSpec, ks: np.ndarray) -> np.ndarray:
    """Profile + wobble + jitter, before any data-quality effects."""
    t_min = _t_minutes(ks)
    if spec.key in _DERIVED_FLOWS:
        source_key, factor, lag_seconds = _DERIVED_FLOWS[spec.key]
        base = factor * _profile(scenario, source_key, t_min - lag_seconds / 60.0)
    else:
        base = _profile(scenario, spec.key, t_min)
    seed = _stream_seed(scenario.seed, spec.key)
    wobble_amp, jitter_sigma = _wobble_noise_amplitudes(spec)
    return (
        base
        + _wobble(seed, t_min, wobble_amp)
        + jitter_sigma * _gaussian(seed, ks, 0x51CE)
    )


def _quality_series(scenario: Scenario, key: str, t_min: np.ndarray) -> np.ndarray:
    quality = np.full(t_min.shape, QUALITY_GOOD, dtype=object)
    for rule in scenario.quality_rules:
        if rule.sensor != key:
            continue
        end = np.inf if rule.end_min is None else rule.end_min
        mask = (t_min >= rule.start_min) & (t_min < end)
        quality[mask] = rule.kind
    return quality


def sensor_series(
    scenario: Scenario, spec: SensorSpec, ks: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Values and quality for one sensor at the given sample indices."""
    t_min = _t_minutes(ks)
    values = _raw_values(scenario, spec, ks)
    quality = _quality_series(scenario, spec.key, t_min)

    # A stale sensor stops updating: freeze at the reading it stuck on.
    for rule in scenario.quality_rules:
        if rule.sensor != spec.key or rule.kind != QUALITY_STALE:
            continue
        end = np.inf if rule.end_min is None else rule.end_min
        mask = (t_min >= rule.start_min) & (t_min < end)
        if not mask.any():
            continue
        freeze_k = max(
            0,
            int(math.floor((rule.start_min + HISTORY_MINUTES) * 60.0 / SAMPLE_SECONDS)),
        )
        frozen_value = float(
            _raw_values(scenario, spec, np.array([freeze_k], dtype=np.int64))[0]
        )
        values = values.copy()
        values[mask] = frozen_value

    missing_mask = quality == QUALITY_MISSING
    if missing_mask.any():
        values = values.copy()
        values[missing_mask] = np.nan
    return values, quality


def generate_process_block(
    scenario: Scenario,
    specs: Sequence[SensorSpec],
    t0: pd.Timestamp,
    ks: np.ndarray,
) -> pd.DataFrame:
    """Long-format samples for all 16 sensors at the given sample indices."""
    timestamps = t0 + pd.to_timedelta(ks * SAMPLE_SECONDS, unit="s")
    frames: list[pd.DataFrame] = []
    for spec in specs:
        values, quality = sensor_series(scenario, spec, ks)
        alarms = [
            classify_alarm(value, spec.limits, sample_quality)
            for value, sample_quality in zip(values.tolist(), quality.tolist())
        ]
        frames.append(
            pd.DataFrame(
                {
                    "timestamp": timestamps,
                    "sensor_key": spec.key,
                    "pid_tag": spec.display_tag,
                    "display_name": spec.display_name,
                    "group_id": spec.group_id,
                    "group_name": spec.group_name,
                    "measurement": spec.measurement,
                    "value": values,
                    "unit": spec.unit,
                    "source": SOURCE_SIMULATED,
                    "quality": quality,
                    "alarm_state": alarms,
                }
            )
        )
    return pd.concat(frames, ignore_index=True)


def generate_electrical_block(
    scenario: Scenario, t0: pd.Timestamp, ks: np.ndarray
) -> pd.DataFrame:
    """Demo-only stack voltage/current (separate from the 16 P&ID sensors)."""
    timestamps = t0 + pd.to_timedelta(ks * SAMPLE_SECONDS, unit="s")
    t_min = _t_minutes(ks)
    columns: dict[str, object] = {"timestamp": timestamps}
    for pseudo_key, column in (
        ("STACK_VOLTAGE", "voltage_v"),
        ("STACK_CURRENT", "current_a"),
    ):
        baseline, wobble_amp, jitter_sigma = _ELECTRICAL_BASE[pseudo_key]
        seed = _stream_seed(scenario.seed, pseudo_key)
        columns[column] = (
            baseline
            + _wobble(seed, t_min, wobble_amp)
            + jitter_sigma * _gaussian(seed, ks, 0x0E1C)
        )
    return pd.DataFrame(columns)


def collect_events(
    block: pd.DataFrame,
    last_alarm: dict[str, str],
    events: list[dict[str, object]],
) -> None:
    """Append alarm-state transitions found in ``block`` to ``events``.

    Duplicate-safety: the caller feeds each sample exactly once (via the
    ``last_k`` pointer in ``advance_sim``), and an event is only recorded when
    a sample's state differs from the sensor's previously recorded state in
    ``last_alarm``. A five-second refresh with unchanged states therefore
    appends nothing, and re-rendering the page cannot re-append old events.
    """
    ordered = block.sort_values("timestamp", kind="mergesort")
    for key, group in ordered.groupby("sensor_key", sort=False):
        previous = last_alarm.get(key)
        for timestamp, state, value, unit, tag, name in zip(
            group["timestamp"],
            group["alarm_state"],
            group["value"],
            group["unit"],
            group["pid_tag"],
            group["display_name"],
        ):
            if previous is not None and state != previous:
                events.append(
                    {
                        "timestamp": timestamp,
                        "sensor_key": key,
                        "pid_tag": tag,
                        "sensor": name,
                        "previous": previous,
                        "new": state,
                        "value": value,
                        "unit": unit,
                        "source": SOURCE_SIMULATED,
                    }
                )
            previous = state
        if previous is not None:
            last_alarm[key] = str(previous)


def _floor_now() -> pd.Timestamp:
    return pd.Timestamp.now(tz=DISPLAY_TZ).floor(f"{SAMPLE_SECONDS}s")


def ensure_sim(scenario_name: str, specs: Sequence[SensorSpec]) -> None:
    """Create (or cleanly regenerate) the demo session for a scenario.

    History is kept in ``st.session_state`` so ordinary widget-driven reruns
    reuse it unchanged; only a scenario change, the Reset demo button or a
    full page refresh starts a new session.
    """
    sim = st.session_state.get("sim")
    if sim is not None and sim["scenario"] == scenario_name:
        return

    scenario = SCENARIOS[scenario_name]
    t_gen = _floor_now()
    t0 = t_gen - pd.Timedelta(seconds=HISTORY_SECONDS)
    ks = np.arange(HISTORY_SAMPLES, dtype=np.int64)

    frame = generate_process_block(scenario, specs, t0, ks)
    events: list[dict[str, object]] = []
    last_alarm: dict[str, str] = {}
    collect_events(frame, last_alarm, events)
    events.sort(key=lambda event: event["timestamp"])
    events = events[-EVENT_LIMIT:]

    st.session_state["sim"] = {
        "scenario": scenario_name,
        "t0": t0,
        "last_k": int(HISTORY_SAMPLES - 1),
        "frame": frame,
        "events": events,
        "last_alarm": last_alarm,
        "elec": generate_electrical_block(scenario, t0, ks),
    }
    advance_sim(specs)


def advance_sim(specs: Sequence[SensorSpec]) -> None:
    """Append only the genuinely new five-second samples up to now."""
    sim = st.session_state.get("sim")
    if sim is None:
        return
    scenario = SCENARIOS[sim["scenario"]]
    now = pd.Timestamp.now(tz=DISPLAY_TZ)
    target_k = int((now - sim["t0"]).total_seconds() // SAMPLE_SECONDS)
    if target_k <= sim["last_k"]:
        return

    ks = np.arange(sim["last_k"] + 1, target_k + 1, dtype=np.int64)
    block = generate_process_block(scenario, specs, sim["t0"], ks)
    collect_events(block, sim["last_alarm"], sim["events"])
    sim["events"].sort(key=lambda event: event["timestamp"])
    sim["events"] = sim["events"][-EVENT_LIMIT:]

    frame = pd.concat([sim["frame"], block], ignore_index=True)
    cutoff = frame["timestamp"].max() - pd.Timedelta(seconds=HISTORY_SECONDS)
    sim["frame"] = frame.loc[frame["timestamp"] >= cutoff].reset_index(drop=True)

    elec_block = generate_electrical_block(scenario, sim["t0"], ks)
    elec = pd.concat([sim["elec"], elec_block], ignore_index=True)
    sim["elec"] = elec.loc[elec["timestamp"] >= cutoff].reset_index(drop=True)
    sim["last_k"] = target_k


def latest_snapshot(frame: pd.DataFrame, specs: Sequence[SensorSpec]) -> pd.DataFrame:
    """Latest sample per sensor, in registry presentation order."""
    latest = (
        frame.sort_values("timestamp", kind="mergesort")
        .groupby("sensor_key", sort=False)
        .tail(1)
        .set_index("sensor_key")
    )
    return latest.reindex([spec.key for spec in specs]).reset_index()


@dataclass(frozen=True)
class FeedStatus:
    label: str
    colour: str
    detail: str


def feed_status(frame: pd.DataFrame) -> FeedStatus:
    """Demo feed state from the age of the newest generated sample."""
    if frame.empty:
        return FeedStatus("Not updating", RED, "No samples generated")
    newest = frame["timestamp"].max()
    age = (pd.Timestamp.now(tz=DISPLAY_TZ) - newest).total_seconds()
    newest_text = format_timestamp(newest)
    if age <= ACTIVE_MAX_AGE_SECONDS:
        return FeedStatus("Demo feed active", SECONDARY, f"Newest sample {newest_text}")
    if age <= DELAYED_MAX_AGE_SECONDS:
        return FeedStatus("Delayed", AMBER, f"Newest sample {format_elapsed(age)} ago")
    return FeedStatus("Not updating", RED, f"Newest sample {format_elapsed(age)} ago")


def alarm_counts(snapshot: pd.DataFrame) -> dict[str, int]:
    states = snapshot["alarm_state"].tolist()
    qualities = snapshot["quality"].tolist()
    return {
        "critical": sum(state in CRITICAL_STATES for state in states),
        "warning": sum(state in WARNING_STATES for state in states),
        "normal": sum(state == STATE_NORMAL for state in states),
        "pending": sum(state == STATE_UNCONFIGURED for state in states),
        "quality": sum(quality != QUALITY_GOOD for quality in qualities),
    }


# ---------------------------------------------------------------------------
# 5. Formatting helpers
# ---------------------------------------------------------------------------


def format_number(value: object, decimals: int) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "—"
    try:
        return f"{float(value):,.{decimals}f}"
    except (TypeError, ValueError):
        return "—"


def format_limit(value: Optional[float], decimals: int) -> str:
    return "—" if value is None else f"{value:,.{decimals}f}"


def format_timestamp(value: object, include_date: bool = False) -> str:
    if value is None or pd.isna(value):
        return "—"
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is not None:
        timestamp = timestamp.tz_convert(DISPLAY_TZ)
    if include_date:
        return timestamp.strftime("%d %b %Y at %H:%M:%S")
    return timestamp.strftime("%H:%M:%S")


def format_elapsed(seconds: float) -> str:
    total = max(0, int(round(seconds)))
    if total < 60:
        return f"{total} second" if total == 1 else f"{total} seconds"
    minutes = total // 60
    if minutes < 60:
        return f"{minutes} minute" if minutes == 1 else f"{minutes} minutes"
    hours = minutes // 60
    return f"{hours} hour" if hours == 1 else f"{hours} hours"


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def _rgba(hex_colour: str, alpha: float) -> str:
    hex_colour = hex_colour.lstrip("#")
    red_v, green_v, blue_v = (int(hex_colour[i : i + 2], 16) for i in (0, 2, 4))
    return f"rgba({red_v},{green_v},{blue_v},{alpha})"


def logo_data_uri(path: Path) -> str:
    """Local logo as a data URI (no remote images); cached per session."""
    cached = st.session_state.get("_logo_uri")
    if cached is not None:
        return str(cached)
    try:
        raw = path.read_bytes()
    except OSError:
        raw = b""
    if raw:
        mime = "image/png" if raw.startswith(b"\x89PNG") else "image/jpeg"
        uri = f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"
    else:
        uri = ""
    st.session_state["_logo_uri"] = uri
    return uri


# ---------------------------------------------------------------------------
# 6. Theme and CSS
# ---------------------------------------------------------------------------

DARK_THEME = {
    "app_bg": (
        "radial-gradient(circle at top right, rgba(167,215,48,0.10) 0%, "
        "rgba(14,17,23,0) 35%), radial-gradient(circle at bottom left, "
        "rgba(78,168,222,0.07) 0%, rgba(14,17,23,0) 40%), #0e1117"
    ),
    "text": "#f2f4f7",
    "subtext": "#9aa0a9",
    "sidebar_grad": (
        "linear-gradient(180deg, rgba(48,52,60,0.98) 0%, "
        "rgba(28,34,43,0.98) 72%, rgba(20,25,32,0.98) 100%)"
    ),
    "sidebar_border": "rgba(255,255,255,0.10)",
    "sidebar_text": "#ffffff",
    "sidebar_sub": "rgba(255,255,255,0.74)",
    "section_label": "rgba(255,255,255,0.66)",
    "card_bg": "linear-gradient(135deg, rgba(167,215,48,0.16), rgba(78,168,222,0.10))",
    "card_border": "rgba(255,255,255,0.12)",
    "radio_bg": "rgba(255,255,255,0.055)",
    "radio_hover": "rgba(167,215,48,0.12)",
    "input_bg": "rgba(255,255,255,0.06)",
    "input_border": "rgba(255,255,255,0.16)",
    "popover_bg": "#1b222b",
    "panel_bg": "linear-gradient(180deg, rgba(27,34,43,0.96) 0%, rgba(22,29,37,0.96) 100%)",
    "panel_border": "rgba(255,255,255,0.10)",
    "table_bg": "rgba(27,34,43,0.96)",
    "table_border": "rgba(255,255,255,0.08)",
    "chart_bg": "rgba(27,34,43,0.45)",
    "chart_border": "rgba(255,255,255,0.06)",
    "hero_bg": (
        "linear-gradient(90deg, rgba(12,16,24,0.92) 0%, "
        "rgba(18,30,22,0.88) 70%, rgba(29,52,33,0.78) 100%)"
    ),
    "hero_border": "rgba(255,255,255,0.12)",
    "logo_filter": "drop-shadow(0 6px 14px rgba(0,0,0,0.35))",
    "soft_bg": "rgba(27,34,43,0.70)",
    "soft_border": "rgba(255,255,255,0.08)",
    "divider": "rgba(255,255,255,0.12)",
}

LIGHT_THEME = {
    "app_bg": (
        "radial-gradient(circle at top right, rgba(167,215,48,0.09) 0%, "
        "rgba(247,249,244,0) 35%), radial-gradient(circle at bottom left, "
        "rgba(73,152,35,0.06) 0%, rgba(247,249,244,0) 40%), #f7f9f4"
    ),
    "text": "#1a2010",
    "subtext": "#4a5240",
    "sidebar_grad": "linear-gradient(180deg, #eef3e6 0%, #e6f0da 100%)",
    "sidebar_border": "rgba(73,152,35,0.20)",
    "sidebar_text": "#1a2010",
    "sidebar_sub": "#4a5240",
    "section_label": "#4a5240",
    "card_bg": "linear-gradient(135deg, rgba(167,215,48,0.18), rgba(73,152,35,0.10))",
    "card_border": "rgba(73,152,35,0.25)",
    "radio_bg": "rgba(167,215,48,0.10)",
    "radio_hover": "rgba(167,215,48,0.22)",
    "input_bg": "rgba(255,255,255,0.85)",
    "input_border": "rgba(73,152,35,0.30)",
    "popover_bg": "#ffffff",
    "panel_bg": "linear-gradient(180deg, #ffffff 0%, #f7f9f4 100%)",
    "panel_border": "rgba(73,152,35,0.15)",
    "table_bg": "#ffffff",
    "table_border": "rgba(73,152,35,0.15)",
    "chart_bg": "rgba(255,255,255,0.80)",
    "chart_border": "rgba(73,152,35,0.14)",
    "hero_bg": (
        "linear-gradient(90deg, rgba(247,249,244,0.97) 0%, "
        "rgba(230,240,218,0.95) 70%, rgba(210,235,185,0.90) 100%)"
    ),
    "hero_border": "rgba(73,152,35,0.20)",
    "logo_filter": "none",
    "soft_bg": "rgba(240,247,224,0.80)",
    "soft_border": "rgba(73,152,35,0.15)",
    "divider": "rgba(73,152,35,0.20)",
}

# Local font stack only: the app must remain fully usable offline, so no
# Google Fonts import (unlike app_v1). Hind is used when installed locally.
_CSS = Template("""
<style>
html, body, [class*="css"] { font-family: ${font_stack}; letter-spacing: 0; }
.stApp { background: ${app_bg}; color: ${text}; }
header[data-testid="stHeader"] { background: transparent; }
[data-testid="stToolbarActions"], [data-testid="stAppDeployButton"],
[data-testid="stMainMenu"], [data-testid="stDecoration"], #MainMenu, footer {
    display: none !important; }
.block-container { max-width:1560px; padding:1.1rem clamp(1rem,2.2vw,2.2rem) 2rem; }
h1,h2,h3,h4,h5,h6 { color:${text} !important; font-weight:700; letter-spacing:0; }
p,span,label,li { color:${text} !important; }
.stCaption,.stMarkdown small { color:${subtext} !important; }

section[data-testid="stSidebar"] > div {
    background:${sidebar_grad}; border-right:1px solid ${sidebar_border}; }
section[data-testid="stSidebar"] .stMarkdown p,
section[data-testid="stSidebar"] .stMarkdown span,
section[data-testid="stSidebar"] .stMarkdown li,
section[data-testid="stSidebar"] label { color:${sidebar_text} !important; }
section[data-testid="stSidebar"] hr { margin:.9rem 0; border-color:${divider}; }
section[data-testid="stSidebar"] [data-testid="stVerticalBlock"] { gap:.55rem; }

.sidebar-title-card { padding:.95rem 1rem .85rem; border-radius:14px;
    background:${card_bg}; border:1px solid ${card_border}; margin-bottom:.6rem; }
.sidebar-kicker { color:${primary} !important; font-size:.76rem; font-weight:700;
    letter-spacing:.06em; text-transform:uppercase; margin:0 0 .2rem; }
.sidebar-title { color:${sidebar_text} !important; font-size:1.18rem; font-weight:700;
    line-height:1.15; margin:0; }
.sidebar-subtitle { color:${sidebar_sub} !important; font-size:.86rem; margin:.3rem 0 0; }
.sidebar-section-label { color:${section_label} !important; font-size:.74rem; font-weight:700;
    letter-spacing:.07em; text-transform:uppercase; margin:.4rem 0 .15rem; }

div[data-baseweb="select"] > div, div[data-baseweb="input"] > div,
.stSelectbox > div > div, .stMultiSelect > div > div,
input[type="number"], .stTextInput input {
    background-color:${input_bg} !important; border-color:${input_border} !important;
    color:${text} !important; }
div[data-baseweb="select"] span, div[data-baseweb="input"] input,
ul[data-testid="stSelectboxVirtualDropdown"] li,
ul[data-testid="stSelectboxVirtualDropdown"] span { color:${text} !important; }
ul[data-testid="stSelectboxVirtualDropdown"] { background:${popover_bg} !important; }

.stButton > button,.stDownloadButton > button { background:${primary}; color:#1d2430;
    font-weight:700; border:none; border-radius:8px; }
.stButton > button:hover,.stDownloadButton > button:hover {
    background:${secondary}; color:#ffffff; }

.hero-banner { display:flex; justify-content:space-between; align-items:center; gap:1.1rem;
    padding:.95rem 1.3rem; border-radius:14px; border:1px solid ${hero_border};
    background:${hero_bg}; margin-bottom:.55rem; }
.hero-copy { max-width:78%; min-width:0; }
.hero-kicker { display:block; color:${primary} !important; font-size:.74rem; font-weight:700;
    letter-spacing:.06em; text-transform:uppercase; margin:0 0 .18rem; }
.hero-title { margin:0; color:${text} !important; font-size:clamp(1.45rem,2.1vw,2.05rem);
    line-height:1.12; font-weight:700; }
.hero-sub { margin:.18rem 0 0; color:${subtext} !important; font-size:1.0rem; font-weight:600; }
.hero-logos { display:flex; align-items:center; justify-content:flex-end; flex:0 0 auto; }
.hero-logos img { height:82px; width:auto; object-fit:contain; filter:${logo_filter}; }
.logo-fallback { color:${primary} !important; font-size:1.5rem; font-weight:800;
    letter-spacing:.02em; }

.badge-row { display:flex; flex-wrap:wrap; gap:.4rem; margin-top:.55rem; align-items:center; }
.badge { display:inline-flex; align-items:center; gap:.35rem; padding:.16rem .6rem;
    border-radius:999px; font-size:.74rem; font-weight:600; letter-spacing:.03em;
    line-height:1.4; white-space:nowrap; }
.badge .dot { width:.5rem; height:.5rem; border-radius:50%; display:inline-block; }

.safety-note { margin:.15rem 0 .9rem; color:${subtext} !important; font-size:.8rem;
    line-height:1.4; }

.stack-grid { display:grid; grid-template-columns:repeat(6,minmax(0,1fr));
    gap:.7rem; margin:.15rem 0 .9rem; }
.stack-card { min-width:0; background:${panel_bg}; border:1px solid ${panel_border};
    border-radius:12px; padding:.6rem .75rem .55rem; box-shadow:0 5px 14px rgba(0,0,0,.10); }
.stack-label { display:block; color:${subtext} !important; font-size:.68rem; font-weight:700;
    letter-spacing:.05em; text-transform:uppercase; margin-bottom:.28rem;
    overflow-wrap:anywhere; }
.stack-value { color:${text} !important; font-size:1.16rem; font-weight:700; line-height:1.15; }
.stack-value-text { color:${text} !important; font-size:.9rem; font-weight:600;
    line-height:1.3; overflow-wrap:anywhere; }
.stack-muted { color:${subtext} !important; font-size:.98rem; font-weight:600; }
.stack-unit { margin-left:.25rem; color:${subtext} !important; font-size:.78rem; font-weight:600; }
.stack-sub { margin-top:.3rem; color:${subtext} !important; font-size:.72rem; line-height:1.35;
    display:flex; align-items:center; gap:.4rem; flex-wrap:wrap; }
.sim-chip { display:inline-block; padding:.05rem .42rem; border-radius:6px;
    background:${amber}; color:#30343c !important; font-size:.62rem; font-weight:700;
    letter-spacing:.05em; }

.rail { display:flex; flex-direction:column; gap:.55rem; }
.rail-item { background:${panel_bg}; border:1px solid ${panel_border}; border-radius:11px;
    padding:.55rem .7rem .5rem; border-left:4px solid ${light_grey};
    box-shadow:0 4px 12px rgba(0,0,0,.08); }
.rail-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; }
.rail-name { color:${text} !important; font-size:.8rem; font-weight:700; }
.rail-status { font-size:.68rem; font-weight:700; padding:.08rem .5rem; border-radius:999px;
    white-space:nowrap; }
.rail-line { margin-top:.22rem; color:${subtext} !important; font-size:.72rem; line-height:1.35; }
.rail-quality { margin-top:.18rem; color:${amber} !important; font-size:.7rem;
    font-weight:600; line-height:1.3; }
.rail-footer { margin-top:.15rem; color:${subtext} !important; font-size:.72rem;
    line-height:1.35; border-top:1px solid ${divider}; padding-top:.5rem; }

.crit-grid { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:.7rem; }
.crit-card { min-width:0; background:${panel_bg}; border:1px solid ${panel_border};
    border-radius:12px; padding:.6rem .75rem .55rem; border-left:4px solid ${light_grey};
    box-shadow:0 5px 14px rgba(0,0,0,.10); }
.crit-top { display:flex; align-items:center; justify-content:space-between; gap:.45rem;
    margin-bottom:.22rem; }
.crit-tag { color:${subtext} !important; font-size:.7rem; font-weight:700;
    letter-spacing:.05em; }
.alarm-badge { font-size:.66rem; font-weight:700; padding:.08rem .5rem; border-radius:999px;
    white-space:nowrap; letter-spacing:.03em; }
.crit-name { color:${text} !important; font-size:.8rem; font-weight:600; line-height:1.25;
    min-height:2.0rem; overflow-wrap:anywhere; }
.crit-note { color:${subtext} !important; font-size:.66rem; line-height:1.3; margin-top:.1rem; }
.crit-value { margin-top:.25rem; color:${text} !important; font-size:1.28rem; font-weight:700;
    line-height:1.1; }
.crit-unit { margin-left:.25rem; color:${subtext} !important; font-size:.8rem; font-weight:600; }
.crit-missing { margin-top:.3rem; color:${subtext} !important; font-size:.98rem; font-weight:600; }
.crit-meta { margin-top:.4rem; display:flex; align-items:center; gap:.4rem; flex-wrap:wrap;
    color:${subtext} !important; font-size:.68rem; }
.qual-chip { display:inline-block; padding:.04rem .42rem; border-radius:6px;
    font-size:.62rem; font-weight:700; letter-spacing:.04em; }
.qual-good { border:1px solid ${secondary}; color:${secondary} !important;
    background:transparent; }
.qual-bad { background:${light_grey}; color:#ffffff !important; }

.status-strip { display:flex; flex-wrap:wrap; gap:.5rem; margin:.85rem 0 .3rem; }
.strip-chip { display:inline-flex; align-items:center; gap:.45rem; padding:.3rem .7rem;
    border-radius:999px; background:${soft_bg}; border:1px solid ${soft_border};
    font-size:.76rem; font-weight:600; color:${text} !important; }
.strip-chip .dot { width:.55rem; height:.55rem; border-radius:50%; display:inline-block; }
.strip-num { font-weight:800; font-size:.86rem; }

.legend-row { display:flex; align-items:flex-start; gap:.45rem; margin:.15rem 0; }
.legend-dot { width:.7rem; height:.7rem; border-radius:4px; flex:0 0 auto; margin-top:.18rem; }
.legend-text { color:${sidebar_text} !important; font-size:.78rem; line-height:1.35; }

.note-inline { margin:.35rem 0 0; color:${subtext} !important; font-size:.76rem;
    line-height:1.45; }
.section-title { margin:1.0rem 0 .55rem; color:${text} !important;
    font-size:1.15rem !important; font-weight:700; line-height:1.25; padding:0 !important; }
.table-note { margin:.5rem 0 0; color:${subtext} !important; font-size:.78rem; line-height:1.4; }
.app-footer { margin:1.2rem 0 0; padding-top:.75rem; color:${subtext} !important;
    border-top:1px solid ${divider}; font-size:.76rem; line-height:1.5; }

.stPlotlyChart { min-height:380px; margin-bottom:.7rem; clear:both; overflow:hidden;
    background:${chart_bg}; border:1px solid ${chart_border}; border-radius:12px;
    padding:.5rem .9rem .2rem .45rem; box-sizing:border-box; }
div[data-testid="stDataFrame"] { overflow:hidden; background:${table_bg};
    border:1px solid ${table_border}; border-radius:12px; padding:.2rem; }

@media (max-width:1250px) {
    .stack-grid { grid-template-columns:repeat(3,minmax(0,1fr)); }
    .crit-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
}
@media (max-width:1080px) {
    .hero-banner { flex-direction:column; align-items:flex-start; }
    .hero-copy { max-width:100%; }
    .hero-logos { justify-content:flex-start; }
    .hero-logos img { height:64px; }
}
@media (max-width:760px) {
    .block-container { padding:3.4rem .8rem 1.5rem; }
    .hero-banner { padding:.85rem .95rem; border-radius:12px; }
    .stack-grid { grid-template-columns:repeat(2,minmax(0,1fr)); gap:.55rem; }
    .crit-grid { grid-template-columns:1fr; gap:.55rem; }
    .crit-name { min-height:0; }
    .stPlotlyChart { min-height:340px; }
}
</style>
""")


def is_light() -> bool:
    return st.session_state.get("theme", "dark") == "light"


def inject_css(theme: str) -> None:
    tokens = dict(LIGHT_THEME if theme == "light" else DARK_THEME)
    tokens.update(
        {
            "primary": PRIMARY,
            "secondary": SECONDARY,
            "amber": AMBER,
            "red": RED,
            "light_grey": LIGHT_GREY,
            "font_stack": FONT_STACK,
        }
    )
    st.markdown(_CSS.substitute(tokens), unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 7. Reusable HTML fragments (all user-editable text is escaped)
# ---------------------------------------------------------------------------


def _badge(
    text: str,
    colour: str,
    *,
    outline: bool = False,
    bold: bool = False,
    text_colour: Optional[str] = None,
    dot: bool = False,
) -> str:
    if outline:
        style = f"border:1px solid {colour}; color:{colour}; background:transparent;"
    else:
        foreground = text_colour or (DARK_GREY if colour == AMBER else "#ffffff")
        style = f"background:{colour}; color:{foreground};"
    if bold:
        style += "font-weight:800;"
    dot_html = f'<span class="dot" style="background:{colour};"></span>' if dot else ""
    return f'<span class="badge" style="{style}">{dot_html}{html.escape(text)}</span>'


def _alarm_badge(state: str) -> str:
    background, foreground = state_badge_colours(state)
    return (
        f'<span class="alarm-badge" style="background:{background}; '
        f'color:{foreground};">{html.escape(alarm_display_text(state))}</span>'
    )


def _quality_chip(quality: str) -> str:
    css = "qual-good" if quality == QUALITY_GOOD else "qual-bad"
    return f'<span class="qual-chip {css}">{html.escape(quality)}</span>'


def _sim_chip() -> str:
    return f'<span class="sim-chip">{SOURCE_SIMULATED}</span>'


def render_header(
    snapshot: pd.DataFrame, frame: pd.DataFrame, scenario_name: str
) -> None:
    feed = feed_status(frame)
    overall = worst_state(snapshot["alarm_state"])
    overall_colour, _ = state_badge_colours(overall)
    overall_text = f"Overall: {SEVERITY_WORD[overall]}"
    if overall in CRITICAL_STATES or overall in WARNING_STATES:
        overall_text += f" ({overall})"
    updated = format_timestamp(frame["timestamp"].max())

    logo_uri = logo_data_uri(LOGO_FILE)
    if logo_uri:
        logo_html = f'<img src="{logo_uri}" alt="HydroStar">'
    else:
        logo_html = '<span class="logo-fallback">HydroStar</span>'

    badges = "".join(
        (
            _badge("DEMO MODE", LIGHT_GREY, outline=True, bold=True),
            _badge("SIMULATED DATA", AMBER, bold=True),
            _badge(f"Scenario: {scenario_name}", WATER_BLUE, outline=True),
            _badge(feed.label, feed.colour, dot=False),
            _badge(f"Updated {updated}", LIGHT_GREY, outline=True),
            _badge(overall_text, overall_colour, bold=True),
        )
    )
    st.markdown(
        '<div class="hero-banner">'
        '<div class="hero-copy">'
        '<span class="hero-kicker">HydroStar · NextGen BETA rig</span>'
        f'<h1 class="hero-title">{html.escape(PAGE_TITLE)}</h1>'
        f'<p class="hero-sub">{html.escape(PAGE_SUBTITLE)}</p>'
        f'<div class="badge-row">{badges}</div>'
        "</div>"
        f'<div class="hero-logos">{logo_html}</div>'
        "</div>"
        '<p class="safety-note">Monitoring and visualisation only — not a '
        "substitute for PLC/SIS protection or plant interlocks. "
        f"All values are simulated. Feed: {html.escape(feed.detail)}. "
        f"Times shown in {DISPLAY_TZ_NAME}.</p>",
        unsafe_allow_html=True,
    )


def _stat_card(
    label: str, value_html: str, sub_html: str = "", simulated: bool = False
) -> str:
    sub_parts = []
    if sub_html:
        sub_parts.append(sub_html)
    if simulated:
        sub_parts.append(_sim_chip())
    sub_block = (
        f'<div class="stack-sub">{" ".join(sub_parts)}</div>' if sub_parts else ""
    )
    return (
        '<div class="stack-card">'
        f'<span class="stack-label">{html.escape(label)}</span>'
        f"<div>{value_html}</div>{sub_block}</div>"
    )


def render_stack_row(
    elec: pd.DataFrame,
    snapshot: pd.DataFrame,
    campaign: str,
    electrolyte: str,
) -> None:
    latest_elec = elec.iloc[-1]
    voltage = float(latest_elec["voltage_v"])
    current = float(latest_elec["current_a"])
    # Power rule: never from voltage alone — always voltage x current / 1000.
    power_kw = voltage * current / 1000.0

    hydrogen_row = snapshot.set_index("sensor_key").loc["FT001_H2"]
    hydrogen_value = hydrogen_row["value"]
    hydrogen_quality = str(hydrogen_row["quality"])
    if hydrogen_quality == QUALITY_MISSING or pd.isna(hydrogen_value):
        hydrogen_html = '<span class="stack-muted">No reading</span>'
    elif hydrogen_quality == QUALITY_STALE:
        hydrogen_html = '<span class="stack-muted">Stale reading</span>'
    else:
        hydrogen_html = (
            f'<span class="stack-value">{format_number(hydrogen_value, 2)}</span>'
            '<span class="stack-unit">Nm³/h</span>'
        )

    cards = [
        _stat_card(
            "Test campaign",
            f'<span class="stack-value-text">{html.escape(campaign)}</span>',
            "Demo metadata — editable in the sidebar",
        ),
        _stat_card(
            "Stack power input",
            f'<span class="stack-value">{power_kw:,.2f}</span>'
            '<span class="stack-unit">kW</span>',
            f"{voltage:,.1f} V × {current:,.1f} A",
            simulated=True,
        ),
        _stat_card(
            "Electrolyte specification",
            f'<span class="stack-value-text">{html.escape(electrolyte)}</span>',
            "Demo metadata — editable in the sidebar",
        ),
        _stat_card(
            "Hydrogen production rate",
            hydrogen_html,
            "FT-001 · latest value",
            simulated=True,
        ),
        # No fake efficiency figures: the HHV/LHV basis and the current and
        # auxiliary-power measurements have not been agreed or supplied.
        _stat_card(
            "Stack efficiency",
            f'<span class="stack-muted">{NOT_CALCULATED}</span>',
            "HHV/LHV basis not agreed",
        ),
        _stat_card(
            "System efficiency",
            f'<span class="stack-muted">{NOT_CALCULATED}</span>',
            "Energy measurements incomplete",
        ),
    ]
    st.markdown(f'<div class="stack-grid">{"".join(cards)}</div>', unsafe_allow_html=True)


def _rail_item_html(
    name: str,
    state: str,
    status_text: str,
    detail: str,
    quality_note: str = "",
) -> str:
    colour, foreground = state_badge_colours(state)
    quality_html = (
        f'<div class="rail-quality">{html.escape(quality_note)}</div>'
        if quality_note
        else ""
    )
    return (
        f'<div class="rail-item" style="border-left-color:{colour};">'
        '<div class="rail-head">'
        f'<span class="rail-name">{html.escape(name)}</span>'
        f'<span class="rail-status" style="background:{colour}; color:{foreground};">'
        f"{html.escape(status_text)}</span>"
        "</div>"
        f'<div class="rail-line">{html.escape(detail)}</div>'
        f"{quality_html}</div>"
    )


def _quality_note(members: pd.DataFrame) -> str:
    stale = int((members["quality"] == QUALITY_STALE).sum())
    missing = int((members["quality"] == QUALITY_MISSING).sum())
    bad = int((members["quality"] == QUALITY_BAD).sum())
    parts = []
    if stale:
        parts.append(f"{stale} stale reading" + ("s" if stale > 1 else ""))
    if missing:
        parts.append(f"{missing} missing reading" + ("s" if missing > 1 else ""))
    if bad:
        parts.append(f"{bad} bad reading" + ("s" if bad > 1 else ""))
    return "Data quality: " + ", ".join(parts) if parts else ""


def render_safety_rail(snapshot: pd.DataFrame, frame: pd.DataFrame) -> None:
    indexed = snapshot.set_index("sensor_key")
    items: list[str] = []

    for name, member_keys, explanation in SAFETY_ITEMS:
        members = indexed.loc[list(member_keys)]
        state = worst_state(members["alarm_state"].tolist())
        if state == STATE_NORMAL:
            detail = f"All within limits. {explanation}"
        elif state == STATE_UNCONFIGURED:
            detail = f"No approved limits configured. {explanation}"
        elif state == STATE_UNKNOWN:
            unknown_tags = members.loc[
                members["alarm_state"] == STATE_UNKNOWN, "pid_tag"
            ].tolist()
            detail = f"Data unavailable for {', '.join(unknown_tags)}. {explanation}"
        else:
            worst_rows = members.loc[members["alarm_state"] == state]
            tags = ", ".join(worst_rows["pid_tag"].tolist())
            detail = f"Worst: {tags} ({state}). {explanation}"
        items.append(
            _rail_item_html(
                name, state, SEVERITY_WORD[state], detail, _quality_note(members)
            )
        )

    feed = feed_status(frame)
    quality_issues = int((snapshot["quality"] != QUALITY_GOOD).sum())
    if feed.label == "Demo feed active":
        feed_state = STATE_NORMAL
    elif feed.label == "Delayed":
        feed_state = "H"
    else:
        feed_state = "HH"
    feed_quality_note = (
        f"{quality_issues} of {len(snapshot)} readings not GOOD"
        if quality_issues
        else ""
    )
    items.append(
        _rail_item_html(
            "Data feed",
            feed_state,
            feed.label,
            f"{feed.detail}. Five-second simulated sampling.",
            feed_quality_note,
        )
    )

    items.append(
        '<div class="rail-footer">Monitoring only — no control commands '
        "or interlocks.</div>"
    )
    st.markdown(f'<div class="rail">{"".join(items)}</div>', unsafe_allow_html=True)


def _critical_card_html(spec: SensorSpec, row: pd.Series) -> str:
    state = str(row["alarm_state"])
    quality = str(row["quality"])
    colour, _ = state_badge_colours(state)
    value = row["value"]

    if quality == QUALITY_MISSING or pd.isna(value):
        value_html = '<div class="crit-missing">No reading</div>'
    elif quality == QUALITY_STALE:
        value_html = '<div class="crit-missing">Stale reading</div>'
    else:
        value_html = (
            f'<div class="crit-value" style="color:{colour};">'
            f"{format_number(value, spec.decimals)}"
            f'<span class="crit-unit">{html.escape(spec.unit)}</span></div>'
        )

    note_html = (
        '<div class="crit-note">Tag pending confirmation</div>'
        if spec.pid_tag == "UNASSIGNED"
        else ""
    )
    return (
        f'<div class="crit-card" style="border-left-color:{colour}; '
        f"background-image:linear-gradient({_rgba(colour, 0.06)}, "
        f'{_rgba(colour, 0.06)});">'
        '<div class="crit-top">'
        f'<span class="crit-tag">{html.escape(spec.display_tag)}</span>'
        f"{_alarm_badge(state)}"
        "</div>"
        f'<div class="crit-name">{html.escape(spec.display_name)}</div>'
        f"{note_html}{value_html}"
        '<div class="crit-meta">'
        f"{_quality_chip(quality)}{_sim_chip()}"
        f"<span>Updated {format_timestamp(row['timestamp'])}</span>"
        "</div></div>"
    )


def render_critical_cards(
    snapshot: pd.DataFrame, specs_map: Mapping[str, SensorSpec]
) -> None:
    indexed = snapshot.set_index("sensor_key")
    cards = [
        _critical_card_html(specs_map[key], indexed.loc[key])
        for key in CRITICAL_CARD_ORDER
    ]
    st.markdown(f'<div class="crit-grid">{"".join(cards)}</div>', unsafe_allow_html=True)


def render_status_strip(snapshot: pd.DataFrame) -> None:
    counts = alarm_counts(snapshot)
    chips = (
        ("Critical alarms", counts["critical"], RED),
        ("Warnings", counts["warning"], AMBER),
        ("Normal configured", counts["normal"], SECONDARY),
        ("Limits pending", counts["pending"], LIGHT_GREY),
        ("Data-quality issues", counts["quality"], LIGHT_GREY),
    )
    chip_html = "".join(
        '<span class="strip-chip">'
        f'<span class="dot" style="background:{colour};"></span>'
        f'<span class="strip-num">{count}</span>{html.escape(label)}</span>'
        for label, count, colour in chips
    )
    st.markdown(f'<div class="status-strip">{chip_html}</div>', unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# 8. All Sensors table
# ---------------------------------------------------------------------------

TABLE_COLUMNS = [
    "Group", "P&ID tag", "Sensor / location", "Current value", "Unit",
    "Alarm state", "Data source", "Data quality", "LL", "L", "H", "HH",
    "Last update",
]


def build_sensor_table(
    snapshot: pd.DataFrame, specs: Sequence[SensorSpec]
) -> tuple[pd.DataFrame, list[str], list[str]]:
    indexed = snapshot.set_index("sensor_key")
    rows: list[dict[str, str]] = []
    states: list[str] = []
    qualities: list[str] = []
    for spec in specs:
        row = indexed.loc[spec.key]
        state = str(row["alarm_state"])
        quality = str(row["quality"])
        value = row["value"]
        if quality == QUALITY_MISSING or pd.isna(value):
            value_text = "No reading"
        elif quality == QUALITY_STALE:
            value_text = "Stale reading"
        else:
            value_text = format_number(value, spec.decimals)
        unit_text = spec.unit + (" (provisional)" if spec.unit_provisional else "")
        rows.append(
            {
                "Group": f"{spec.group_id} — {spec.group_name}",
                "P&ID tag": spec.display_tag,
                "Sensor / location": spec.display_name,
                "Current value": value_text,
                "Unit": unit_text,
                "Alarm state": alarm_display_text(state),
                "Data source": SOURCE_SIMULATED,
                "Data quality": quality,
                "LL": format_limit(spec.limits.get("LL"), spec.decimals),
                "L": format_limit(spec.limits.get("L"), spec.decimals),
                "H": format_limit(spec.limits.get("H"), spec.decimals),
                "HH": format_limit(spec.limits.get("HH"), spec.decimals),
                "Last update": format_timestamp(row["timestamp"]),
            }
        )
        states.append(state)
        qualities.append(quality)
    return pd.DataFrame(rows, columns=TABLE_COLUMNS), states, qualities


_AMBER_TEXT = "#B97B00"  # readable amber-family text on light backgrounds


def style_sensor_table(
    table: pd.DataFrame, states: list[str], qualities: list[str]
):
    """Colour value/alarm/quality cells only (never the whole row)."""
    css = pd.DataFrame("", index=table.index, columns=table.columns)
    value_col = table.columns.get_loc("Current value")
    alarm_col = table.columns.get_loc("Alarm state")
    quality_col = table.columns.get_loc("Data quality")
    for i, (state, quality) in enumerate(zip(states, qualities)):
        background, foreground = state_badge_colours(state)
        text_colour = _AMBER_TEXT if background == AMBER else background
        css.iloc[i, value_col] = (
            f"background-color:{_rgba(background, 0.14)}; "
            f"color:{text_colour}; font-weight:700;"
        )
        css.iloc[i, alarm_col] = (
            f"background-color:{background}; color:{foreground}; font-weight:600;"
        )
        if quality == QUALITY_GOOD:
            css.iloc[i, quality_col] = f"color:{SECONDARY}; font-weight:700;"
        else:
            css.iloc[i, quality_col] = (
                f"background-color:{LIGHT_GREY}; color:#ffffff; font-weight:600;"
            )
    return table.style.apply(lambda _: css, axis=None)


def snapshot_csv(snapshot: pd.DataFrame, specs: Sequence[SensorSpec]) -> bytes:
    indexed = snapshot.set_index("sensor_key")
    rows = []
    for spec in specs:
        row = indexed.loc[spec.key]
        timestamp = pd.Timestamp(row["timestamp"])
        rows.append(
            {
                "timestamp": timestamp.isoformat(timespec="seconds"),
                "sensor_key": spec.key,
                "pid_tag": spec.display_tag,
                "display_name": spec.display_name,
                "group_id": spec.group_id,
                "group_name": spec.group_name,
                "measurement": spec.measurement,
                "value": row["value"],
                "unit": spec.unit,
                "source": SOURCE_SIMULATED,
                "quality": row["quality"],
                "alarm_state": row["alarm_state"],
                "limit_LL": spec.limits.get("LL"),
                "limit_L": spec.limits.get("L"),
                "limit_H": spec.limits.get("H"),
                "limit_HH": spec.limits.get("HH"),
            }
        )
    return pd.DataFrame(rows).to_csv(index=False).encode("utf-8")


def render_all_sensors_tab(
    snapshot: pd.DataFrame, specs: Sequence[SensorSpec], scenario_name: str
) -> None:
    table, states, qualities = build_sensor_table(snapshot, specs)
    st.dataframe(
        style_sensor_table(table, states, qualities),
        hide_index=True,
        height=620,
        **STRETCH,
    )
    st.markdown(
        '<p class="note-inline">NX-PID-001 shows FT-003 on both the oxygen '
        "product outlet and the nitrogen feed; both rows are kept as separate "
        "instruments (internal keys FT003_O2 and FT003_N2) until the tag "
        "collision is confirmed. The two gas analysers are labelled on the "
        "P&amp;ID without unique instrument tags, so they are shown as "
        "Tag pending.</p>"
        '<p class="note-inline">LL/L/H/HH are provisional dashboard limits '
        "for layout and alarm-behaviour testing — not PLC/SIS or approved "
        "plant trip settings. All values are simulated.</p>",
        unsafe_allow_html=True,
    )
    stamp = pd.Timestamp.now(tz=DISPLAY_TZ).strftime("%Y%m%d_%H%M%S")
    st.download_button(
        "Download current 16-sensor snapshot (CSV)",
        data=snapshot_csv(snapshot, specs),
        file_name=f"hydrostar_demo_snapshot_{_slug(scenario_name)}_{stamp}.csv",
        mime="text/csv",
        key="download_snapshot",
    )


# ---------------------------------------------------------------------------
# 9. Trend charts and event log
# ---------------------------------------------------------------------------


def downsample(frame: pd.DataFrame, max_points: int = MAX_CHART_POINTS) -> pd.DataFrame:
    """Stride-based downsampling that keeps genuine samples (and their NaN
    gaps) instead of averaging across missing data."""
    if len(frame) <= max_points:
        return frame
    step = max(1, math.ceil(len(frame) / max_points))
    positions = list(range(0, len(frame), step))
    if positions[-1] != len(frame) - 1:
        positions.append(len(frame) - 1)
    return frame.iloc[positions].reset_index(drop=True)


def chart_theme(light: bool) -> dict[str, str]:
    if light:
        return {
            "panel": "#ffffff",
            "font": "#1a2010",
            "grid": "rgba(0,0,0,0.08)",
            "line": "rgba(0,0,0,0.20)",
            "hover_bg": "#f0f7e0",
            "hover_border": "rgba(73,152,35,0.45)",
        }
    return {
        "panel": "#1b222b",
        "font": "#f2f4f7",
        "grid": "rgba(255,255,255,0.08)",
        "line": "rgba(255,255,255,0.18)",
        "hover_bg": "#111821",
        "hover_border": "rgba(167,215,48,0.35)",
    }


def build_trend_chart(
    spec: SensorSpec,
    sensor_frame: pd.DataFrame,
    window_label: str,
    scenario_name: str,
    window_start: pd.Timestamp,
    window_end: pd.Timestamp,
    light: bool,
) -> go.Figure:
    theme = chart_theme(light)
    axis_font = {"color": theme["font"], "family": FONT_STACK, "size": 11}
    decimals = spec.decimals

    x_values = sensor_frame["timestamp"].dt.tz_localize(None)
    y_values = sensor_frame["value"]
    custom = np.column_stack(
        (
            sensor_frame["quality"].astype(str),
            sensor_frame["alarm_state"].astype(str),
        )
    )

    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=x_values,
            y=y_values,
            mode="lines",
            name=spec.display_tag,
            line={
                "color": MEASUREMENT_LINE_COLOURS.get(spec.measurement, WATER_BLUE),
                "width": 2.2,
            },
            connectgaps=False,  # preserve missing-data gaps
            customdata=custom,
            hovertemplate=(
                "%{x|%d %b %H:%M:%S}<br>"
                + f"{spec.display_name}: %{{y:.{decimals}f}} {spec.unit}<br>"
                + "Alarm: %{customdata[1]}<br>"
                + "Quality: %{customdata[0]}<br>"
                + "Source: Simulated"
                + f"<extra>{spec.display_tag}</extra>"
            ),
        )
    )

    limits = spec.limits
    finite = y_values.to_numpy(dtype=float)
    finite = finite[np.isfinite(finite)]
    candidates = [value for value in limits.values() if value is not None]
    if finite.size:
        candidates.extend([float(finite.min()), float(finite.max())])
    if candidates:
        y_low = min(candidates)
        y_high = max(candidates)
        span = y_high - y_low
        pad = span * 0.14 if span > 0 else max(abs(y_high), 1.0) * 0.25
        y_bottom, y_top = y_low - pad, y_high + pad
        figure.update_yaxes(range=[y_bottom, y_top])
    else:
        y_bottom, y_top = 0.0, 1.0

    high = limits.get("H")
    high_high = limits.get("HH")
    low = limits.get("L")
    low_low = limits.get("LL")

    # Subtle alarm regions — only where limits are actually configured.
    if high is not None:
        figure.add_hrect(
            y0=high, y1=high_high if high_high is not None else y_top,
            fillcolor=_rgba(AMBER, 0.07), line_width=0, layer="below",
        )
    if high_high is not None:
        figure.add_hrect(
            y0=high_high, y1=y_top,
            fillcolor=_rgba(RED, 0.07), line_width=0, layer="below",
        )
    if low is not None:
        figure.add_hrect(
            y0=low_low if low_low is not None else y_bottom, y1=low,
            fillcolor=_rgba(AMBER, 0.07), line_width=0, layer="below",
        )
    if low_low is not None:
        figure.add_hrect(
            y0=y_bottom, y1=low_low,
            fillcolor=_rgba(RED, 0.07), line_width=0, layer="below",
        )

    # Threshold lines with labels, corner positions chosen so the four level
    # labels (LL, L, H, HH) do not sit on top of each other.
    threshold_layout = (
        ("HH", high_high, RED, "dot", "top right"),
        ("H", high, AMBER, "dash", "top left"),
        ("L", low, AMBER, "dash", "bottom left"),
        ("LL", low_low, RED, "dot", "bottom right"),
    )
    for name, level, colour, dash, position in threshold_layout:
        if level is None:
            continue
        figure.add_hline(
            y=level,
            line={"color": colour, "width": 1.4, "dash": dash},
            annotation_text=f"{name} = {level:g} {spec.unit}",
            annotation_position=position,
            annotation_font={"color": colour, "size": 10, "family": FONT_STACK},
        )
    if not spec.configured:
        figure.add_annotation(
            xref="paper", yref="paper", x=0.01, y=0.98,
            text=NO_APPROVED_LIMITS, showarrow=False,
            font={"color": LIGHT_GREY, "size": 11, "family": FONT_STACK},
        )

    figure.update_layout(
        title={
            "text": f"{spec.display_tag} — {spec.display_name} ({spec.unit})",
            "font": {"color": theme["font"], "size": 14, "family": FONT_STACK},
            "x": 0.01,
        },
        height=380,
        margin={"l": 54, "r": 20, "t": 44, "b": 44},
        paper_bgcolor=theme["panel"],
        plot_bgcolor=theme["panel"],
        font={"family": FONT_STACK, "color": theme["font"], "size": 12},
        showlegend=False,
        hoverlabel={
            "bgcolor": theme["hover_bg"],
            "bordercolor": theme["hover_border"],
            "font": {"color": theme["font"], "family": FONT_STACK, "size": 12},
        },
        # uirevision keeps zoom/pan across five-second refreshes; it resets
        # only when the sensor, window or scenario changes.
        uirevision=f"{spec.key}|{window_label}|{scenario_name}",
    )
    figure.update_xaxes(
        range=[
            window_start.tz_localize(None),
            window_end.tz_localize(None),
        ],
        gridcolor=theme["grid"],
        linecolor=theme["line"],
        zeroline=False,
        automargin=True,
        hoverformat="%d %b %Y at %H:%M:%S",
        tickfont=axis_font,
    )
    figure.update_yaxes(
        title_text=spec.unit,
        gridcolor=theme["grid"],
        linecolor=theme["line"],
        zeroline=False,
        automargin=True,
        tickfont=axis_font,
        title_font=axis_font,
    )
    return figure


def events_frame(events: list[dict[str, object]], specs_map: Mapping[str, SensorSpec]) -> pd.DataFrame:
    rows = []
    for event in reversed(events):  # newest first
        spec = specs_map.get(str(event["sensor_key"]))
        decimals = spec.decimals if spec else 2
        rows.append(
            {
                "Timestamp": format_timestamp(event["timestamp"], include_date=True),
                "P&ID tag": event["pid_tag"],
                "Sensor": event["sensor"],
                "Previous state": alarm_display_text(str(event["previous"])),
                "New state": alarm_display_text(str(event["new"])),
                "Value": format_number(event["value"], decimals),
                "Unit": event["unit"],
                "Source": event["source"],
            }
        )
    return pd.DataFrame(
        rows,
        columns=[
            "Timestamp", "P&ID tag", "Sensor", "Previous state", "New state",
            "Value", "Unit", "Source",
        ],
    )


def style_events(table: pd.DataFrame, events: list[dict[str, object]]):
    css = pd.DataFrame("", index=table.index, columns=table.columns)
    previous_col = table.columns.get_loc("Previous state")
    new_col = table.columns.get_loc("New state")
    ordered = list(reversed(events))
    for i, event in enumerate(ordered):
        for column, state in (
            (previous_col, str(event["previous"])),
            (new_col, str(event["new"])),
        ):
            background, foreground = state_badge_colours(state)
            css.iloc[i, column] = (
                f"background-color:{background}; color:{foreground}; font-weight:600;"
            )
    return table.style.apply(lambda _: css, axis=None)


def events_csv(events: list[dict[str, object]]) -> bytes:
    rows = [
        {
            "timestamp": pd.Timestamp(event["timestamp"]).isoformat(timespec="seconds"),
            "sensor_key": event["sensor_key"],
            "pid_tag": event["pid_tag"],
            "sensor": event["sensor"],
            "previous_state": event["previous"],
            "new_state": event["new"],
            "value": event["value"],
            "unit": event["unit"],
            "source": event["source"],
        }
        for event in reversed(events)
    ]
    return pd.DataFrame(rows).to_csv(index=False).encode("utf-8")


def window_history_csv(window_frame: pd.DataFrame) -> bytes:
    export = window_frame.copy()
    export["timestamp"] = export["timestamp"].map(
        lambda value: pd.Timestamp(value).isoformat(timespec="seconds")
    )
    return export.to_csv(index=False).encode("utf-8")


def render_trends_tab(
    frame: pd.DataFrame,
    specs_map: Mapping[str, SensorSpec],
    selected: Sequence[str],
    window_label: str,
    scenario_name: str,
    events: list[dict[str, object]],
) -> None:
    newest = frame["timestamp"].max()
    minutes = WINDOW_OPTIONS[window_label]
    cutoff = newest - pd.Timedelta(minutes=minutes)
    window_frame = frame.loc[frame["timestamp"] >= cutoff]

    if not selected:
        st.markdown(
            '<p class="note-inline">Select one or two sensors in the sidebar '
            "to plot their trends.</p>",
            unsafe_allow_html=True,
        )
    else:
        selected = list(selected)[:2]
        columns = st.columns(len(selected), gap="medium") if len(selected) == 2 else [
            st.container()
        ]
        for container, key in zip(columns, selected):
            spec = specs_map[key]
            sensor_frame = downsample(
                window_frame.loc[window_frame["sensor_key"] == key]
                .sort_values("timestamp", kind="mergesort")
                .reset_index(drop=True)
            )
            figure = build_trend_chart(
                spec, sensor_frame, window_label, scenario_name,
                cutoff, newest, is_light(),
            )
            with container:
                st.plotly_chart(
                    figure, config=CHART_CONFIG, key=f"trend_{key}", **STRETCH
                )

    stamp = pd.Timestamp.now(tz=DISPLAY_TZ).strftime("%Y%m%d_%H%M%S")
    st.download_button(
        f"Download {window_label} history for all 16 sensors (CSV)",
        data=window_history_csv(window_frame),
        file_name=(
            f"hydrostar_demo_history_{_slug(scenario_name)}_"
            f"{_slug(window_label)}_{stamp}.csv"
        ),
        mime="text/csv",
        key="download_history",
    )

    st.markdown(
        '<h2 class="section-title">Alarm and event log</h2>', unsafe_allow_html=True
    )
    if not events:
        st.markdown(
            '<p class="note-inline">No alarm-state transitions have been '
            "recorded in this demo session yet.</p>",
            unsafe_allow_html=True,
        )
        return
    table = events_frame(events, specs_map)
    st.dataframe(
        style_events(table, events),
        hide_index=True,
        height=min(430, 36 * (len(table) + 1)),
        **STRETCH,
    )
    st.markdown(
        f'<p class="table-note">Showing the most recent {len(table)} '
        f"alarm-state transitions (a maximum of {EVENT_LIMIT} is retained). "
        "Events are recorded only when a state changes — never on an "
        "unchanged five-second refresh.</p>",
        unsafe_allow_html=True,
    )
    st.download_button(
        "Download alarm-event log (CSV)",
        data=events_csv(events),
        file_name=f"hydrostar_demo_events_{_slug(scenario_name)}_{stamp}.csv",
        mime="text/csv",
        key="download_events",
    )


# ---------------------------------------------------------------------------
# 10. Sidebar
# ---------------------------------------------------------------------------


def _reset_demo() -> None:
    st.session_state.pop("sim", None)


def render_sidebar(specs: Sequence[SensorSpec]) -> dict[str, object]:
    specs_map = {spec.key: spec for spec in specs}
    with st.sidebar:
        st.markdown(
            '<div class="sidebar-title-card">'
            '<p class="sidebar-kicker">HydroStar</p>'
            '<p class="sidebar-title">NextGen Electrolyser Testing and Validation</p>'
            '<p class="sidebar-subtitle">Demo mode — all data simulated</p>'
            "</div>",
            unsafe_allow_html=True,
        )

        st.markdown(
            '<p class="sidebar-section-label">Dashboard controls</p>',
            unsafe_allow_html=True,
        )
        saved_theme = st.query_params.get("theme", st.session_state.get("theme", "dark"))
        light_mode = st.toggle(
            "Light mode", value=saved_theme == "light", key="light_mode_toggle"
        )
        theme = "light" if light_mode else "dark"
        st.session_state["theme"] = theme
        if st.query_params.get("theme") != theme:
            st.query_params["theme"] = theme

        scenario_name = st.selectbox(
            "Demo scenario",
            list(SCENARIO_ORDER),
            index=list(SCENARIO_ORDER).index(DEFAULT_SCENARIO),
            key="scenario_select",
        )
        window_label = st.selectbox(
            "Time range",
            list(WINDOW_OPTIONS),
            index=list(WINDOW_OPTIONS).index(DEFAULT_WINDOW),
            key="time_range",
        )
        selected = st.multiselect(
            "Trend sensors (maximum two)",
            options=list(EXPECTED_KEYS),
            default=DEFAULT_TREND_SENSORS,
            max_selections=2,
            format_func=lambda key: (
                f"{specs_map[key].display_tag} — {specs_map[key].display_name}"
            ),
            key="trend_sensors",
        )
        st.button("Reset demo", key="reset_demo", on_click=_reset_demo, **STRETCH)
        if getattr(st, "fragment", None) is None:  # pragma: no cover
            st.button("Refresh now", key="manual_refresh", **STRETCH)
            st.caption(
                "This Streamlit version does not support automatic fragment "
                "refresh; use Refresh now to pull in new demo samples."
            )

        st.markdown(
            '<p class="sidebar-section-label">Demo metadata</p>',
            unsafe_allow_html=True,
        )
        campaign = st.text_input(
            "Test campaign", value=DEFAULT_CAMPAIGN, key="campaign_text"
        )
        electrolyte = st.text_input(
            "Electrolyte specification",
            value=DEFAULT_ELECTROLYTE,
            key="electrolyte_text",
        )

        st.markdown(
            '<p class="sidebar-section-label">Safety legend</p>',
            unsafe_allow_html=True,
        )
        legend = (
            (SECONDARY, "Green — NORMAL"),
            (AMBER, "Amber — L or H"),
            (RED, "Red — LL or HH"),
            (LIGHT_GREY, "Grey — missing, stale or no approved limits"),
        )
        st.markdown(
            "".join(
                '<div class="legend-row">'
                f'<span class="legend-dot" style="background:{colour};"></span>'
                f'<span class="legend-text">{html.escape(text)}</span></div>'
                for colour, text in legend
            ),
            unsafe_allow_html=True,
        )

        with st.expander("Engineering notes"):
            st.markdown(
                "- All values on this dashboard are simulated.\n"
                "- Alarm limits are provisional dashboard values, not "
                "approved set-points.\n"
                "- The duplicated FT-003 tag (oxygen outlet and nitrogen "
                "feed) requires confirmation.\n"
                "- The two gas-analyser instrument tags require confirmation.\n"
                "- CT-001 and nitrogen-feed flow units are provisional.\n"
                "- Flow and conductivity alarm limits have not been approved.\n"
                "- This dashboard does not replace PLC/SIS protection or "
                "plant interlocks."
            )

    return {
        "theme": theme,
        "scenario": scenario_name,
        "window": window_label,
        "selected": list(selected),
        "campaign": campaign.strip() or DEFAULT_CAMPAIGN,
        "electrolyte": electrolyte.strip() or DEFAULT_ELECTROLYTE,
    }


# ---------------------------------------------------------------------------
# 11. Internal validation (Section 20 of the build brief)
# ---------------------------------------------------------------------------


def run_self_checks(specs: Sequence[SensorSpec]) -> None:
    """Assert the alarm engine and registry behave exactly as specified.

    Runs silently on startup; ordinary users never see successful assertions.
    """
    level = {"LL": -10.0, "L": -5.0, "H": 5.0, "HH": 10.0}
    for value, expected in (
        (-11.0, "LL"), (-10.0, "LL"), (-7.0, "L"), (-5.0, "L"), (0.0, "NORMAL"),
        (5.0, "H"), (7.0, "H"), (10.0, "HH"), (11.0, "HH"),
    ):
        got = classify_alarm(value, level, QUALITY_GOOD)
        assert got == expected, f"level {value} -> {got}, expected {expected}"

    temperature = {"LL": None, "L": None, "H": 50.0, "HH": 60.0}
    for value, expected in (
        (49.9, "NORMAL"), (50.0, "H"), (59.9, "H"), (60.0, "HH"),
    ):
        got = classify_alarm(value, temperature, QUALITY_GOOD)
        assert got == expected, f"temperature {value} -> {got}, expected {expected}"

    pressure = {"LL": None, "L": None, "H": 2.5, "HH": 4.0}
    for value, expected in (
        (2.49, "NORMAL"), (2.50, "H"), (3.99, "H"), (4.00, "HH"),
    ):
        got = classify_alarm(value, pressure, QUALITY_GOOD)
        assert got == expected, f"pressure {value} -> {got}, expected {expected}"

    gas = {"LL": None, "L": None, "H": 2.0, "HH": 3.0}
    for value, expected in (
        (1.99, "NORMAL"), (2.00, "H"), (2.99, "H"), (3.00, "HH"),
    ):
        got = classify_alarm(value, gas, QUALITY_GOOD)
        assert got == expected, f"gas {value} -> {got}, expected {expected}"

    assert classify_alarm(None, level, QUALITY_GOOD) == STATE_UNKNOWN
    assert classify_alarm(float("nan"), level, QUALITY_GOOD) == STATE_UNKNOWN
    assert classify_alarm(25.0, temperature, QUALITY_MISSING) == STATE_UNKNOWN
    assert classify_alarm(25.0, temperature, QUALITY_STALE) == STATE_UNKNOWN
    assert classify_alarm(25.0, temperature, QUALITY_BAD) == STATE_UNKNOWN
    unconfigured = {"LL": None, "L": None, "H": None, "HH": None}
    assert classify_alarm(1.8, unconfigured, QUALITY_GOOD) == STATE_UNCONFIGURED

    assert worst_state(["H", "HH", "NORMAL"]) == "HH"
    assert worst_state(["L", "LL"]) == "LL"
    assert worst_state(["NORMAL", "H"]) == "H"
    assert worst_state(["NORMAL", "UNKNOWN", "UNCONFIGURED"]) == "NORMAL"
    assert worst_state(["UNCONFIGURED", "UNKNOWN"]) == "UNCONFIGURED"
    assert worst_state([]) == STATE_UNKNOWN

    # Registry expectations: exactly 16 unique keys, and the duplicated
    # displayed tag FT-003 kept as two separate instruments.
    keys = [spec.key for spec in specs]
    assert len(keys) == 16, f"expected 16 sensors, found {len(keys)}"
    assert len(set(keys)) == 16, "internal sensor keys are not unique"
    ft003 = {spec.key: spec.pid_tag for spec in specs if spec.pid_tag == "FT-003"}
    assert set(ft003) == {"FT003_O2", "FT003_N2"}, (
        "FT-003 must map to exactly FT003_O2 and FT003_N2"
    )

    # Event extraction: split processing equals single-pass processing, and a
    # block with no state change appends nothing.
    demo_times = pd.date_range("2026-01-01", periods=6, freq="5s", tz="UTC")
    demo_block = pd.DataFrame(
        {
            "timestamp": demo_times,
            "sensor_key": ["X"] * 6,
            "pid_tag": ["X-001"] * 6,
            "display_name": ["Demo sensor"] * 6,
            "value": [0.0, 0.0, 6.0, 6.0, 11.0, 11.0],
            "unit": ["mm"] * 6,
            "alarm_state": ["NORMAL", "NORMAL", "H", "H", "HH", "HH"],
        }
    )
    single_events: list[dict[str, object]] = []
    collect_events(demo_block, {}, single_events)
    split_events: list[dict[str, object]] = []
    split_state: dict[str, str] = {}
    collect_events(demo_block.iloc[:3], split_state, split_events)
    collect_events(demo_block.iloc[3:], split_state, split_events)
    assert len(single_events) == 2, f"expected 2 events, got {len(single_events)}"
    assert len(split_events) == len(single_events), "split processing duplicated events"
    unchanged: list[dict[str, object]] = []
    collect_events(demo_block.iloc[4:], {"X": "HH"}, unchanged)
    assert not unchanged, "unchanged states must not append events"


# ---------------------------------------------------------------------------
# 12. Live dashboard (five-second fragment refresh with fallback)
# ---------------------------------------------------------------------------


def live_fragment(func: Callable[..., None]) -> Callable[..., None]:
    fragment = getattr(st, "fragment", None)
    if fragment is None:  # pragma: no cover - older Streamlit fallback
        return func
    return fragment(run_every=REFRESH_INTERVAL)(func)


@live_fragment
def render_dashboard(specs: Sequence[SensorSpec]) -> None:
    specs_map = {spec.key: spec for spec in specs}
    scenario_name = str(st.session_state.get("scenario_select", DEFAULT_SCENARIO))
    window_label = str(st.session_state.get("time_range", DEFAULT_WINDOW))
    if window_label not in WINDOW_OPTIONS:
        window_label = DEFAULT_WINDOW
    selected = [
        key
        for key in st.session_state.get("trend_sensors", DEFAULT_TREND_SENSORS)
        if key in specs_map
    ][:2]
    campaign = str(
        st.session_state.get("campaign_text", DEFAULT_CAMPAIGN)
    ).strip() or DEFAULT_CAMPAIGN
    electrolyte = str(
        st.session_state.get("electrolyte_text", DEFAULT_ELECTROLYTE)
    ).strip() or DEFAULT_ELECTROLYTE

    ensure_sim(scenario_name, specs)
    advance_sim(specs)
    sim = st.session_state["sim"]
    frame: pd.DataFrame = sim["frame"]
    snapshot = latest_snapshot(frame, specs)

    render_header(snapshot, frame, scenario_name)
    render_stack_row(sim["elec"], snapshot, campaign, electrolyte)

    rail_column, cards_column = st.columns([0.24, 0.76], gap="medium")
    with rail_column:
        render_safety_rail(snapshot, frame)
    with cards_column:
        render_critical_cards(snapshot, specs_map)

    render_status_strip(snapshot)

    all_sensors_tab, trends_tab = st.tabs(["All Sensors", "Trends and Events"])
    with all_sensors_tab:
        render_all_sensors_tab(snapshot, specs, scenario_name)
    with trends_tab:
        render_trends_tab(
            frame, specs_map, selected, window_label, scenario_name, sim["events"]
        )

    st.markdown(
        '<p class="app-footer">Demo mode · All values simulated locally · '
        "Nothing is uploaded or stored outside this browser session · "
        f"Times shown in {DISPLAY_TZ_NAME} · Provisional dashboard limits — "
        "not PLC/SIS set-points.</p>",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# 13. Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    st.set_page_config(
        page_title=PAGE_TITLE,
        page_icon=str(LOGO_FILE) if LOGO_FILE.exists() else None,
        layout="wide",
        initial_sidebar_state="auto",
    )
    try:
        specs = load_registry(REGISTRY_FILE)
    except RegistryError as exc:
        st.error(str(exc))
        st.stop()
        return
    try:
        run_self_checks(specs)
    except AssertionError as exc:
        st.error(
            "Internal validation failed, so the dashboard was stopped rather "
            f"than show incorrect alarm behaviour. Details: {exc}"
        )
        st.stop()
        return

    controls = render_sidebar(specs)
    inject_css(str(controls["theme"]))
    render_dashboard(specs)


if __name__ == "__main__":
    main()
